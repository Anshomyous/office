jQuery(document).ready(function ($) {

    var data = document.getElementsByClassName('td-pb-article-list');
    if (data.length > 0) {        
        $(".category-uncategorized" ).each(function() {
            var id = $(this).attr('id');
            var url = $(this).find('.item-details h3 a').attr('href');
            var value = url.split('/');  
                var result = id.replace(id, value[7]);
                $(this).attr('id',result);            
          });
    }
});